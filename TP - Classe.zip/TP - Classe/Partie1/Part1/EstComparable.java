package Part1;

public interface EstComparable {
    int compareA(Object o);
    
}
